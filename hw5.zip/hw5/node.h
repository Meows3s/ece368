//pos defs
#define LEFT 0
#define RIGHT 1
#define TOP 2
#define BOTTOM 3

//bridge defs
#define BRIDGE 0

//seen defs
#define SEEN 1
#define UNSEEN 0

//undiscovered distance
#define MAX_DIST 999999999
#define NULL_DIST 999999999

typedef struct node_{
  int* bridge; //bridge rotation weights
  int* pos; //x and y coordinates of the node
  int seen[4]; //one resolution per direction
  
  struct node_* nbor[4]; //array of node neighbors (oh no)
  struct node_* closest[4];
  int distFromSource[4]; //one distance per incoming direction
}node;

typedef struct terminalNode_{
  node** nbor; //terminal node can have n neighbors
  node* closest;
  int distFromSource; //0 for start node, shortest dist for end node
}terminalNode;

typedef struct graph_{
  int nrow;
  int ncol;
  node*** data; //2d array of node pointers (node addresses)
  terminalNode* start;
  terminalNode* end;
}graph;
